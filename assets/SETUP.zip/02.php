<?php

	echo 'hello ajax';
	// sleep(1);
?>