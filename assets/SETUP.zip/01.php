<?php
	echo 'hello ajax';
	sleep(5);
?>